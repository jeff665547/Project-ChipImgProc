var searchData=
[
  ['reg_5fmat_2ehpp_151',['reg_mat.hpp',['../marker_2detection_2reg__mat_8hpp.html',1,'(Global Namespace)'],['../gridding_2reg__mat_8hpp.html',1,'(Global Namespace)']]],
  ['reg_5fmat_5finfer_152',['reg_mat_infer',['../reg__mat__infer_8hpp.html#a0a10f825dc6c55cff115c8d04fe8e5b1',1,'chipimgproc::marker::detection']]],
  ['reg_5fmat_5finfer_2ehpp_153',['reg_mat_infer.hpp',['../reg__mat__infer_8hpp.html',1,'']]],
  ['reg_5fmat_5fno_5frot_154',['reg_mat_no_rot',['../reg__mat__no__rot_8hpp.html#ace6866f9aaa15fa902fad44938102acb',1,'chipimgproc::marker::detection']]],
  ['reg_5fmat_5fno_5frot_2ehpp_155',['reg_mat_no_rot.hpp',['../reg__mat__no__rot_8hpp.html',1,'']]],
  ['regmat_156',['RegMat',['../classchipimgproc_1_1gridding_1_1_reg_mat.html',1,'chipimgproc::gridding::RegMat'],['../classchipimgproc_1_1marker_1_1detection_1_1_reg_mat.html',1,'chipimgproc::marker::detection::RegMat']]],
  ['regmatinfer_157',['RegMatInfer',['../classchipimgproc_1_1marker_1_1detection_1_1_reg_mat_infer.html',1,'chipimgproc::marker::detection']]],
  ['regmatnorot_158',['RegMatNoRot',['../structchipimgproc_1_1marker_1_1detection_1_1_reg_mat_no_rot.html',1,'chipimgproc::marker::detection']]],
  ['replace_5ftile_159',['replace_tile',['../structchipimgproc_1_1margin_1_1_param.html#a0084b6ae5db8644df87b95d128ce31c2',1,'chipimgproc::margin::Param']]],
  ['reset_160',['reset',['../classchipimgproc_1_1aruco_1_1_detector.html#a24bebe0c0f758938ebdb8c5b8bc45dd3',1,'chipimgproc::aruco::Detector::reset()'],['../structchipimgproc_1_1aruco_1_1_mk_img_dict.html#aacd671aee6205fadcbee753d42af63ac',1,'chipimgproc::aruco::MkImgDict::reset()']]],
  ['result_161',['Result',['../structchipimgproc_1_1gridding_1_1_result.html',1,'chipimgproc::gridding::Result'],['../structchipimgproc_1_1margin_1_1_result.html',1,'chipimgproc::margin::Result&lt; FLOAT &gt;'],['../structchipimgproc_1_1_multi_tiled_mat_1_1_min_c_v_all_data_1_1_result.html',1,'chipimgproc::MultiTiledMat&lt; FLOAT, GLID &gt;::MinCVAllData::Result']]],
  ['result_2ehpp_162',['result.hpp',['../gridding_2result_8hpp.html',1,'(Global Namespace)'],['../margin_2result_8hpp.html',1,'(Global Namespace)']]],
  ['roi_163',['roi',['../structchipimgproc_1_1stat_1_1_mats.html#a007d2472766145c1bf3d0f2b7a4c7161',1,'chipimgproc::stat::Mats']]],
  ['rows_164',['rows',['../structchipimgproc_1_1_grid_raw_img.html#aacf46d8eef71175f334e82f13c9e832e',1,'chipimgproc::GridRawImg::rows()'],['../structchipimgproc_1_1_multi_tiled_mat.html#ab9113e4dea16ed9d9870d3931561f263',1,'chipimgproc::MultiTiledMat::rows()']]]
];
