var searchData=
[
  ['bright_2dfield_20marker_20detection_386',['Bright-Field Marker Detection',['../md_doc_modules_bright-field-marker-detection.html',1,'']]]
];
