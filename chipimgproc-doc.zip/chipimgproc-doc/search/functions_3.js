var searchData=
[
  ['decode_270',['decode',['../structchipimgproc_1_1aruco_1_1_utils.html#a68921e8b4e7ddbefdd08ae8a5ece2eca',1,'chipimgproc::aruco::Utils']]],
  ['detect_5fmarkers_271',['detect_markers',['../classchipimgproc_1_1aruco_1_1_detector.html#a85dc09da96e7c23356aa867ecee1973c',1,'chipimgproc::aruco::Detector']]],
  ['dictionary_272',['Dictionary',['../classchipimgproc_1_1aruco_1_1_dictionary.html#ac7c2711eba9bfe7d8db38016d02695b0',1,'chipimgproc::aruco::Dictionary::Dictionary()=default'],['../classchipimgproc_1_1aruco_1_1_dictionary.html#a0df7cabdde8b4039e64ff8ba9159ae00',1,'chipimgproc::aruco::Dictionary::Dictionary(const std::int32_t coding_bits, const std::int32_t maxcor_bits)']]],
  ['dump_273',['dump',['../structchipimgproc_1_1_multi_tiled_mat.html#a7a430c85d0a7bded1ed0e71a7af7fe29',1,'chipimgproc::MultiTiledMat']]]
];
