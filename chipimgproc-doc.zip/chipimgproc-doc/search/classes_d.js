var searchData=
[
  ['xdirect_231',['XDirect',['../structchipimgproc_1_1_x_direct.html',1,'chipimgproc']]]
];
