var searchData=
[
  ['originpos_221',['OriginPos',['../structchipimgproc_1_1_origin_pos.html',1,'chipimgproc']]]
];
