var searchData=
[
  ['cell_5fis_5fmarker_262',['cell_is_marker',['../structchipimgproc_1_1_multi_tiled_mat.html#ac719f131f3710b821374dede8d6d03ca',1,'chipimgproc::MultiTiledMat']]],
  ['cell_5flevel_5fstitch_5fpoint_263',['cell_level_stitch_point',['../structchipimgproc_1_1_multi_tiled_mat.html#a3e3cd0ddc80aff67465c379534f47c6a',1,'chipimgproc::MultiTiledMat::cell_level_stitch_point(int x, int y) const'],['../structchipimgproc_1_1_multi_tiled_mat.html#a8da5eb91c8fede5d822bf4fecae90559',1,'chipimgproc::MultiTiledMat::cell_level_stitch_point(int x, int y)']]],
  ['cell_5flevel_5fstitch_5fpoints_264',['cell_level_stitch_points',['../structchipimgproc_1_1_multi_tiled_mat.html#ae9771045647e25a883b14b0e53f11c1a',1,'chipimgproc::MultiTiledMat::cell_level_stitch_points() const'],['../structchipimgproc_1_1_multi_tiled_mat.html#a14a4675ad680f61516c931b64baaaef7',1,'chipimgproc::MultiTiledMat::cell_level_stitch_points()']]],
  ['clean_5fborder_265',['clean_border',['../structchipimgproc_1_1_grid_raw_img.html#a3b2733e40d33675e36f9114b1ca8401a',1,'chipimgproc::GridRawImg']]],
  ['clone_266',['clone',['../structchipimgproc_1_1_grid_raw_img.html#a4b0295f2dee46dd620e71970b4cc0163',1,'chipimgproc::GridRawImg']]],
  ['coding_5fbits_267',['coding_bits',['../classchipimgproc_1_1aruco_1_1_dictionary.html#a36a85b17018178063bb0943c1c4b777f',1,'chipimgproc::aruco::Dictionary']]],
  ['cols_268',['cols',['../structchipimgproc_1_1_grid_raw_img.html#a752782631cd6719feb8fcf07fb779a83',1,'chipimgproc::GridRawImg::cols()'],['../structchipimgproc_1_1_multi_tiled_mat.html#a7c9cb316b427469d96b551804cbcdec1',1,'chipimgproc::MultiTiledMat::cols()']]],
  ['compute_5fmaxcor_5fbits_269',['compute_maxcor_bits',['../classchipimgproc_1_1aruco_1_1_dictionary.html#a19cd512afa4eca13bcb544241d202c7b',1,'chipimgproc::aruco::Dictionary']]]
];
