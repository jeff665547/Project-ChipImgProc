var searchData=
[
  ['pat_5fnum_361',['pat_num',['../structchipimgproc_1_1marker_1_1_layout.html#a48c516c0bfc2d081572ba2aa9981f9e9',1,'chipimgproc::marker::Layout']]]
];
