var searchData=
[
  ['score_365',['score',['../structchipimgproc_1_1marker_1_1detection_1_1_m_k_region.html#a61005181bba32569ec9eb68e9969aa2d',1,'chipimgproc::marker::detection::MKRegion']]],
  ['seg_5frate_366',['seg_rate',['../structchipimgproc_1_1margin_1_1_param.html#a76da69d49ec13192fcbc0cf9531bbe7a',1,'chipimgproc::margin::Param']]],
  ['stat_5fmats_367',['stat_mats',['../structchipimgproc_1_1margin_1_1_result.html#ace206328b69c210e02c1339a04f18341',1,'chipimgproc::margin::Result']]],
  ['stddev_368',['stddev',['../structchipimgproc_1_1stat_1_1_mats.html#ab0c64a39713557d42332c9873bf0a34f',1,'chipimgproc::stat::Mats::stddev()'],['../structchipimgproc_1_1stat_1_1_cell.html#ae8b2a95cde4d3787b014fe7093ec0725',1,'chipimgproc::stat::Cell::stddev()']]]
];
