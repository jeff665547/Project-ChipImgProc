var indexSectionsWithContent =
{
  0: "abcdefgilmnoprstuvxy",
  1: "abcdgilmoprtux",
  2: "abcdgilmpru",
  3: "abcdefgimorstxy",
  4: "bcdfgilmnprstvxy",
  5: "cdfgit",
  6: "dps",
  7: "abfiop"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Pages"
};

