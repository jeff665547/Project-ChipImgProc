var searchData=
[
  ['calibrate_15',['Calibrate',['../structchipimgproc_1_1rotation_1_1_calibrate.html',1,'chipimgproc::rotation']]],
  ['calibrate_2ehpp_16',['calibrate.hpp',['../calibrate_8hpp.html',1,'']]],
  ['candi_5fmks_5fcl_17',['candi_mks_cl',['../structchipimgproc_1_1marker_1_1_des.html#a9d35518d5d2fed0b69641d1fd60701f5',1,'chipimgproc::marker::Des']]],
  ['candi_5fmks_5fcl_5fmask_18',['candi_mks_cl_mask',['../structchipimgproc_1_1marker_1_1_des.html#a0a308a77b4707fcedfc0a38af7179198',1,'chipimgproc::marker::Des']]],
  ['candi_5fmks_5fpx_19',['candi_mks_px',['../structchipimgproc_1_1marker_1_1_des.html#a9be9d65a5e53de96d040c0d587ab4251',1,'chipimgproc::marker::Des']]],
  ['candi_5fmks_5fpx_5fmask_20',['candi_mks_px_mask',['../structchipimgproc_1_1marker_1_1_des.html#a1da847dfeb73684f6a770cd295bc7700',1,'chipimgproc::marker::Des']]],
  ['cell_21',['Cell',['../structchipimgproc_1_1stat_1_1_cell.html',1,'chipimgproc::stat']]],
  ['cell_2ehpp_22',['cell.hpp',['../cell_8hpp.html',1,'']]],
  ['cell_3c_20float_20_3e_23',['Cell&lt; float &gt;',['../structchipimgproc_1_1stat_1_1_cell.html',1,'chipimgproc::stat']]],
  ['cell_5fis_5fmarker_24',['cell_is_marker',['../structchipimgproc_1_1_multi_tiled_mat.html#ac719f131f3710b821374dede8d6d03ca',1,'chipimgproc::MultiTiledMat']]],
  ['cell_5flevel_5fstitch_5fpoint_25',['cell_level_stitch_point',['../structchipimgproc_1_1_multi_tiled_mat.html#a3e3cd0ddc80aff67465c379534f47c6a',1,'chipimgproc::MultiTiledMat::cell_level_stitch_point(int x, int y) const'],['../structchipimgproc_1_1_multi_tiled_mat.html#a8da5eb91c8fede5d822bf4fecae90559',1,'chipimgproc::MultiTiledMat::cell_level_stitch_point(int x, int y)']]],
  ['cell_5flevel_5fstitch_5fpoints_26',['cell_level_stitch_points',['../structchipimgproc_1_1_multi_tiled_mat.html#ae9771045647e25a883b14b0e53f11c1a',1,'chipimgproc::MultiTiledMat::cell_level_stitch_points() const'],['../structchipimgproc_1_1_multi_tiled_mat.html#a14a4675ad680f61516c931b64baaaef7',1,'chipimgproc::MultiTiledMat::cell_level_stitch_points()']]],
  ['cellinfos_27',['CellInfos',['../structchipimgproc_1_1_multi_tiled_mat.html#ad22fcb4ca080e383f99ce79e0701b65b',1,'chipimgproc::MultiTiledMat']]],
  ['clean_5fborder_28',['clean_border',['../structchipimgproc_1_1_grid_raw_img.html#a3b2733e40d33675e36f9114b1ca8401a',1,'chipimgproc::GridRawImg']]],
  ['clone_29',['clone',['../structchipimgproc_1_1_grid_raw_img.html#a4b0295f2dee46dd620e71970b4cc0163',1,'chipimgproc::GridRawImg']]],
  ['coding_5fbits_30',['coding_bits',['../classchipimgproc_1_1aruco_1_1_dictionary.html#a36a85b17018178063bb0943c1c4b777f',1,'chipimgproc::aruco::Dictionary']]],
  ['cols_31',['cols',['../structchipimgproc_1_1_grid_raw_img.html#a752782631cd6719feb8fcf07fb779a83',1,'chipimgproc::GridRawImg::cols()'],['../structchipimgproc_1_1_multi_tiled_mat.html#a7c9cb316b427469d96b551804cbcdec1',1,'chipimgproc::MultiTiledMat::cols()']]],
  ['compute_5fmaxcor_5fbits_32',['compute_maxcor_bits',['../classchipimgproc_1_1aruco_1_1_dictionary.html#a19cd512afa4eca13bcb544241d202c7b',1,'chipimgproc::aruco::Dictionary']]],
  ['const_2eh_33',['const.h',['../const_8h.html',1,'']]],
  ['cv_34',['cv',['../structchipimgproc_1_1stat_1_1_mats.html#a017c6117e50d5f3d3e880ed80ac9bd5d',1,'chipimgproc::stat::Mats::cv()'],['../structchipimgproc_1_1stat_1_1_cell.html#a6da095615ddff0eefa817e5de90e2075',1,'chipimgproc::stat::Cell::cv()']]]
];
