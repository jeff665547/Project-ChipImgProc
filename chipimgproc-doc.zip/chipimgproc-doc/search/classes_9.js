var searchData=
[
  ['param_222',['Param',['../structchipimgproc_1_1margin_1_1_param.html',1,'chipimgproc::margin']]],
  ['pseudo_223',['Pseudo',['../structchipimgproc_1_1gridding_1_1_pseudo.html',1,'chipimgproc::gridding']]]
];
