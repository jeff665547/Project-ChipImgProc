var searchData=
[
  ['num_138',['num',['../structchipimgproc_1_1stat_1_1_mats.html#a53d2931f08eb3fddd1f35104a53cc3d4',1,'chipimgproc::stat::Mats::num()'],['../structchipimgproc_1_1stat_1_1_cell.html#aa4995059a24e168eafa20af1ebf7bbb3',1,'chipimgproc::stat::Cell::num()']]]
];
