var searchData=
[
  ['identify_303',['identify',['../classchipimgproc_1_1aruco_1_1_dictionary.html#aab1cac0969d06f9fee1cef5447e021dc',1,'chipimgproc::aruco::Dictionary::identify(const std::uint64_t query, std::int32_t &amp;index, const std::vector&lt; std::int32_t &gt; &amp;candidates, const std::int32_t maxcor_bits=-1) const'],['../classchipimgproc_1_1aruco_1_1_dictionary.html#ae7139ccc89cdd93ebec37250a16d9ba7',1,'chipimgproc::aruco::Dictionary::identify(const std::uint64_t query, std::int32_t &amp;index) const']]],
  ['infer_5fmarker_5fregions_304',['infer_marker_regions',['../structchipimgproc_1_1marker_1_1detection_1_1_reg_mat_no_rot.html#a8112fa5277719ceb652081d5ce68d03c',1,'chipimgproc::marker::detection::RegMatNoRot']]],
  ['info_305',['info',['../structchipimgproc_1_1marker_1_1detection_1_1_m_k_region.html#ab14197e985ede13f2e0c0d16add51a87',1,'chipimgproc::marker::detection::MKRegion']]],
  ['iterationcali_306',['IterationCali',['../structchipimgproc_1_1rotation_1_1_iteration_cali.html#a14d2e2ae823264ad8ba4340c450142b6',1,'chipimgproc::rotation::IterationCali']]]
];
