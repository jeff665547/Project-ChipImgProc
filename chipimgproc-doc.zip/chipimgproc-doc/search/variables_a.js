var searchData=
[
  ['reg_5fmat_5finfer_362',['reg_mat_infer',['../reg__mat__infer_8hpp.html#a0a10f825dc6c55cff115c8d04fe8e5b1',1,'chipimgproc::marker::detection']]],
  ['reg_5fmat_5fno_5frot_363',['reg_mat_no_rot',['../reg__mat__no__rot_8hpp.html#ace6866f9aaa15fa902fad44938102acb',1,'chipimgproc::marker::detection']]],
  ['replace_5ftile_364',['replace_tile',['../structchipimgproc_1_1margin_1_1_param.html#a0084b6ae5db8644df87b95d128ce31c2',1,'chipimgproc::margin::Param']]]
];
