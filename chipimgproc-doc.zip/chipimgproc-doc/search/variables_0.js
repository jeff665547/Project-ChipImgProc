var searchData=
[
  ['best_5fmk_5fidx_336',['best_mk_idx',['../structchipimgproc_1_1marker_1_1_des.html#af651245b33ab19908d8e011f94443b24',1,'chipimgproc::marker::Des']]],
  ['bg_337',['bg',['../structchipimgproc_1_1stat_1_1_mats.html#a4c232b7a5bccd667e63737ba2d3822f1',1,'chipimgproc::stat::Mats::bg()'],['../structchipimgproc_1_1stat_1_1_cell.html#ae9ff6f1dbe44ce4911f068e1827577cd',1,'chipimgproc::stat::Cell::bg()']]],
  ['bits_5fto_5fmarker_338',['bits_to_marker',['../bits__to__marker_8hpp.html#a8568c834197ec3dce28ff812a6798f8d',1,'chipimgproc::aruco']]],
  ['border_5fpx_339',['border_px',['../structchipimgproc_1_1marker_1_1_layout.html#acee0c95391496eddad6c239b44349f9d',1,'chipimgproc::marker::Layout']]]
];
