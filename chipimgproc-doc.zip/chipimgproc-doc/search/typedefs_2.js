var searchData=
[
  ['floattype_376',['FloatType',['../structchipimgproc_1_1stat_1_1_mats.html#a9487f6ef30fca1e0c6490b2fdca9f493',1,'chipimgproc::stat::Mats::FloatType()'],['../structchipimgproc_1_1stat_1_1_cell.html#a9aae9d63f7b692745610013855cc6b5a',1,'chipimgproc::stat::Cell::FloatType()'],['../structchipimgproc_1_1_multi_tiled_mat.html#a5203951569493642b7b3429200ee600f',1,'chipimgproc::MultiTiledMat::FloatType()']]]
];
