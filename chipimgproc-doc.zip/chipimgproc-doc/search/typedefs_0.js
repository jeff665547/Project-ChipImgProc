var searchData=
[
  ['cellinfos_374',['CellInfos',['../structchipimgproc_1_1_multi_tiled_mat.html#ad22fcb4ca080e383f99ce79e0701b65b',1,'chipimgproc::MultiTiledMat']]]
];
