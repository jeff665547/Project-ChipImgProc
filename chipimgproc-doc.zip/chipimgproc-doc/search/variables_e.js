var searchData=
[
  ['x_5fi_372',['x_i',['../structchipimgproc_1_1marker_1_1detection_1_1_m_k_region.html#abe67776fb673b7944d7a0c173a0cb4d2',1,'chipimgproc::marker::detection::MKRegion']]]
];
