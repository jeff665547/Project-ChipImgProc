var searchData=
[
  ['score_165',['score',['../structchipimgproc_1_1marker_1_1detection_1_1_m_k_region.html#a61005181bba32569ec9eb68e9969aa2d',1,'chipimgproc::marker::detection::MKRegion']]],
  ['score_5fmat_166',['score_mat',['../structchipimgproc_1_1marker_1_1detection_1_1_reg_mat_no_rot.html#aa5ef3d1206c60661072f30be114b3ed2',1,'chipimgproc::marker::detection::RegMatNoRot']]],
  ['seg_5frate_167',['seg_rate',['../structchipimgproc_1_1margin_1_1_param.html#a76da69d49ec13192fcbc0cf9531bbe7a',1,'chipimgproc::margin::Param']]],
  ['set_5fdetector_5fext_168',['set_detector_ext',['../classchipimgproc_1_1marker_1_1detection_1_1_aruco_reg_mat.html#a7a7f57b4a12d491a63023b709895d057',1,'chipimgproc::marker::detection::ArucoRegMat']]],
  ['set_5fdict_169',['set_dict',['../classchipimgproc_1_1marker_1_1detection_1_1_aruco_reg_mat.html#ad8833b21082dc27886524547555b2361',1,'chipimgproc::marker::detection::ArucoRegMat::set_dict(const nlohmann::json &amp;db, const std::string &amp;key)'],['../classchipimgproc_1_1marker_1_1detection_1_1_aruco_reg_mat.html#ae29bf3a7eb9ee7f42e2ab56e6854d6ca',1,'chipimgproc::marker::detection::ArucoRegMat::set_dict(const std::string &amp;path, const std::string &amp;key)']]],
  ['set_5freg_5fmat_5fdist_170',['set_reg_mat_dist',['../structchipimgproc_1_1marker_1_1_layout.html#a23cd90993e4268813027a2b7b7a3a5d5',1,'chipimgproc::marker::Layout']]],
  ['set_5fsingle_5fmk_5fpat_171',['set_single_mk_pat',['../structchipimgproc_1_1marker_1_1_layout.html#a564932e986fbc1d533b1d1d2d7e770a0',1,'chipimgproc::marker::Layout']]],
  ['set_5fsingle_5fpat_5fbest_5fmk_172',['set_single_pat_best_mk',['../structchipimgproc_1_1marker_1_1_layout.html#a85a4d45b80ca24c176f33228d0393655',1,'chipimgproc::marker::Layout']]],
  ['stat_5fmats_173',['stat_mats',['../structchipimgproc_1_1margin_1_1_result.html#ace206328b69c210e02c1339a04f18341',1,'chipimgproc::margin::Result']]],
  ['state_174',['State',['../structchipimgproc_1_1_mat_unit.html#a2a86b83743aa325b056a57df711c0398',1,'chipimgproc::MatUnit']]],
  ['stddev_175',['stddev',['../structchipimgproc_1_1stat_1_1_mats.html#ab0c64a39713557d42332c9873bf0a34f',1,'chipimgproc::stat::Mats::stddev()'],['../structchipimgproc_1_1stat_1_1_cell.html#ae8b2a95cde4d3787b014fe7093ec0725',1,'chipimgproc::stat::Cell::stddev()']]]
];
