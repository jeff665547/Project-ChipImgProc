var searchData=
[
  ['tiled_5fmat_369',['tiled_mat',['../structchipimgproc_1_1margin_1_1_param.html#a691d96f3be63cced964d1e95b6f772a9',1,'chipimgproc::margin::Param']]],
  ['tiles_370',['tiles',['../structchipimgproc_1_1gridding_1_1_result.html#a2a5c3b68e19c2f69a1f2039d3bc19786',1,'chipimgproc::gridding::Result']]]
];
