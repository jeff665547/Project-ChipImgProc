var searchData=
[
  ['gl_5fx_348',['gl_x',['../structchipimgproc_1_1gridding_1_1_result.html#a21ee5e20555e05a721762ecbeed23ee4',1,'chipimgproc::gridding::Result']]],
  ['gl_5fy_349',['gl_y',['../structchipimgproc_1_1gridding_1_1_result.html#a5932ba15e15440b94ea0cab23175d99f',1,'chipimgproc::gridding::Result']]]
];
