var searchData=
[
  ['state_384',['State',['../structchipimgproc_1_1_mat_unit.html#a2a86b83743aa325b056a57df711c0398',1,'chipimgproc::MatUnit']]]
];
