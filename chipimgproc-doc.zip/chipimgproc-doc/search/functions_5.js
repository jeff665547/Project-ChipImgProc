var searchData=
[
  ['from_5fjson_276',['from_json',['../classchipimgproc_1_1aruco_1_1_dictionary.html#a8c68230cce455bb6394ef09bbe7c2a2b',1,'chipimgproc::aruco::Dictionary']]]
];
